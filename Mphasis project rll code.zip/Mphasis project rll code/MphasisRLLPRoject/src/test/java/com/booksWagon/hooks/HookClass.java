package com.booksWagon.hooks;

public class HookClass {

}
