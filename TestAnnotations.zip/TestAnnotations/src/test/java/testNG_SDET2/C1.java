package testNG_SDET2;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class C1 {
	@Test
	void ABC() {
		System.out.println("this is xyz from C1...");
	}
	
	@BeforeTest
	void bt() {
		System.out.println("this is BeforeTest method...");
	}
}
