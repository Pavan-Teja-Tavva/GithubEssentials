package testNG_SDET2;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import junit.framework.Assert;

public class HardVsSoftAssertions {
	@Test
//	void test_hardassertions() {
//		System.out.println("testing");
//		
//		Assert.assertEquals(1,1);
//		
//		System.out.println("testing");
//	}
	
	void test_softassertions() {
		System.out.println("testing");
		
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(1,2);
		
		System.out.println("testing");
		
		sa.assertAll();
	}
}
