package testNG_SDET2;

import org.testng.annotations.Test;

import junit.framework.Assert;

public class HardAssertions {
	@Test
	void test() {
//		Assert.assertEquals("xyz", "xyz");
//		Assert.assertEquals(123,345);
		
		Assert.assertTrue(true);;
//		Assert.assertTrue(false);
	}
}
