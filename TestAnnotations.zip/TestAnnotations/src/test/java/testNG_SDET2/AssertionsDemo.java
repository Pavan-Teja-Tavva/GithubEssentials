package testNG_SDET2;

import org.testng.annotations.Test;

import junit.framework.Assert;

public class AssertionsDemo {
	@Test
	void testTitle() {
		String exp_title = "OpenCart";
		String act_title = "OpenCart";
		
	/*	if (exp_title.equals(act_title)) {
			System.out.println("Passed");
		} else {
			System.out.println("Failed");
		} */
		
		Assert.assertEquals(exp_title, act_title);
		
		if (exp_title.equals(act_title)) {
			System.out.println("Passed");
			Assert.assertTrue(true);
		} else {
			System.out.println("Failed");
			Assert.assertTrue(false);
		} 
	}
}
