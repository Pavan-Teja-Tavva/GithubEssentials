package Scenario1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class HerokuScenario {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://katalon-demo-cura.herokuapp.com");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"top\"]/div/h1"));
		String word = text.getText();
		System.out.println(word.equals("CURA Healthcare Service"));
		
		WebElement appointment = driver.findElement(By.xpath("//*[@id='btn-make-appointment']"));
		appointment.click();
		
		driver.findElement(By.xpath("//*[@id='txt-username']")).sendKeys("John Doe");
		driver.findElement(By.xpath("//*[@id='txt-password']")).sendKeys("ThisIsNotAPassword");
		
		driver.findElement(By.xpath("//*[@id='btn-login']")).click();
		
		WebElement text1 = driver.findElement(By.xpath("//*[@id='appointment']/div/div/div/h2"));
		String word1 = text1.getText();
		System.out.println(word1.equals("Make Appointment"));
		 
		WebElement sel = driver.findElement(By.xpath("//*[@id='combo_facility']"));
		Select select = new Select(sel);
		select.selectByVisibleText("Seoul CURA Healthcare Center");
		
		WebElement check = driver.findElement(By.xpath("//*[@id='appointment']/div/div/form/div[2]/div/label"));
		check.click();
		
		WebElement radio = driver.findElement(By.xpath("//*[@id='radio_program_medicare']"));
		radio.click();
		
		WebElement Cal = driver.findElement(By.xpath("//input[@id='txt_visit_date']"));
		Cal.sendKeys("30/04/2025");
		
		WebElement comment = driver.findElement(By.xpath("//textarea[@id='txt_comment']"));
		comment.sendKeys("Select the required options");
		
		WebElement book = driver.findElement(By.xpath("//button[@id='btn-book-appointment']"));
		book.click();
		
		WebElement confirm = driver.findElement(By.xpath("//*[@id='summary']/div/div/div[1]/h2"));
		String Confirm = confirm.getText();
		System.out.println(Confirm.equals("Appointment Confirmation"));
		
		System.out.println("Finally appointment has been booked sir!!");
		
		
	}
}
