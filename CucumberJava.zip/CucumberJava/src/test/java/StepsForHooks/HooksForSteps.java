package StepsForHooks;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HooksForSteps {
	
	WebDriver driver = null;
	
	@Before
	public void browserSetUp() {
		
		System.out.println("I am inside browserSetUp");
		driver = new ChromeDriver();
		
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
	}
	
	@After
	public void tearDown() {
		System.out.println("I am inside teardown");
		driver.close();
		driver.quit();
	}
	
	BeforeStep
	@Given("user is on login page")
	public void use_is_on_login_page() {
		System.out.println("Step Inside - user is on login page");
	}
	
	@When ("user enters valid username and password")
	public void user_enters_valid_username_and_password() {
		System.out.println("Step Inside - user enters valid username and password");
	}

	@And("clicks on login button")
	public void clicks_on_login_button() {
		System.out.println("Step Inside - clicks on login button");
	}
	
	@Then ("user is navigated to the home page")
	public void user_is_navigated_to_the_home_page() {
		System.out.println("Step Inside - user is navigated to the home page");
	}

}
