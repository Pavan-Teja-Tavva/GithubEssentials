package StepDefinitions;


@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Feature", )
public class TestRunner {
	
}
