package StepDefinitions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginDemoSteps {
	
//	WebDriver driver = null;
//	
//	@Given("browser is open")
//	public void browser_is_open() {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("Inside step - browser is open");
//		
//		driver = new ChromeDriver();
//		
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
//		driver.manage().window().maximize();
//	}
//
//	@And("user is on login page")
//	public void user_is_on_login_page() {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("Inside step - user is on login page");
//		
//		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//	}
//
//	@When("user enters username and password")
//	public void user_enters_username_and_password() {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("Inside step - user enters username and password");
//		
//		driver.findElement(By.name("username")).sendKeys("Pavan Teja");
//		driver.findElement(By.name("password")).sendKeys("12345");
//
//	}
//	
//	@And("user clicks on login") 
//	public void user_clicks_on_login() {
//		System.out.println("Inside step - user clicks on login");
//		
//		driver.findElement(By.xpath("//button[@type='submit']"));
//	}
//	
//	@Then("user is navigated to the home page")
//	public void usere_is_navigated_to_the_home_page() {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("Inside step - user is navigated to the home page");
//		
//		driver.findElement(By.id("logout")).isDisplayed();
//		
//		driver.close();
//		driver.quit();
	}
}
