package Cucumber_demo_nopCommerce.Cucumber_demo_nopCommerce;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
