package Day4XPath;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;

public class TestCase_004 {
	
	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.amazon.in");
		driver.manage().window().maximize();
		
//		xpath with single attribute
//		driver.findElement(By.xpath("//input[@placeholder='Search']")).sendKeys("shirt");
		
//		xpath with multiple attributes
//		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox' and @aria-label='Search Amazon.in']")).sendKeys("shirt");
		
//		xpath with inner text - text() doubt
//		driver.findElement(By.xpath("a[text() = \r\n"
//				+ "        Cart\r\n"
//				+ "        ]")).click();
		
//		xpath with text elements
//		Boolean isDisplayed = driver.findElement(By.xpath("//h2[text()='Starting ₹149 | Headphones']")).isDisplayed();
//		System.out.println(isDisplayed);
		
//		String value = driver.findElement(By.xpath("//h2[text()='Starting ₹149 | Headphones']")).getText();
//		System.out.println(value);
		
//		xpath with contains
//		driver.findElement(By.xpath("//input[contains(@id, 'twotab']")).sendKeys("shirt");
		
//		xpath with starts-with
		driver.findElement(By.xpath("//*[starts-with(@id, 'twotab']")).sendKeys("shirt");
	}
}
