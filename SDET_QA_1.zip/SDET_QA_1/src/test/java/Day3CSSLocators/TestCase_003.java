package Day3CSSLocators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.edge.EdgeDriver;

public class TestCase_003 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.amazon.com");
		driver.manage().window().maximize();
		
//		tag id			tag#id
//		driver.findElement(By.cssSelector("input#twotabsearchtextbox")).sendKeys("shirt");
		
//		tag className   tag.className
//		driver.findElement(By.cssSelector("input.nav-input")).sendKeys("shirt");
		
//		tag attribute   tag[attribute='value']
		driver.findElement(By.cssSelector("input[placeholder='Search Amazon']")).sendKeys("shirt");
		
//		tag class attribute
		driver.findElement(By.cssSelector("input.nav-input[name='field-keywords']")).sendKeys("shirt");
	}
}
