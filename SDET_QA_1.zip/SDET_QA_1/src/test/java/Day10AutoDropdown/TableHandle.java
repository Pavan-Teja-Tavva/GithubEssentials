package Day10AutoDropdown;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TableHandle {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		driver.manage().window().maximize();
		
//		1) find total number of rows in a table
		/*int rows = driver.findElements(By.xpath("//table[@name='BookTable']//tr")).size(); // for multiple tables 
		System.out.println(rows); */
		int rows = driver.findElements(By.xpath("//table[@id='customers']//tr")).size();
		/*int rows = driver.findElements(By.tagName("tr")).size(); //for single table
		System.out.println(rows);*/
		
//		2) find the total number of columns in a table
		/*int cols = driver.findElements(By.xpath("//table[@name='BookTable']//th")).size();
		System.out.println(cols);*/
		
//		3) Read data from specific row and column (ex: 5th row and 1st column)
		/*String bookName = driver.findElement(By.xpath("//table[@name='BookTable']//tr[5]//td[1]")).getText();
		System.out.println(bookName);*/
		
//		4) read all data from the table
		/*for (int r  = 0; r < rows; r++) {
			for (int c = 0; c < cols; c++) {
				String value = driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//t["+c+"]")).getText();
				System.out.println(value);
			}
		}*/
		
//		5) Print book names whose author is mukesh
		/*for (int r = 2; r <= rows; r++) {
			String authorName = driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[2]")).getText();
			
			if(authorName.equals("Mukesh")) {
				String bookName1 = driver.findElement(By.xpath("//table[@name='BookTable']//tr[\"+r+\"]//td[1]")).getText();
				System.out.println(bookName + "\t" + authorName);
			}
		}*/
		
//		6) Find total price of all books
		for (int r = 2; r <= rows; r++) {
			String name = driver.findElement(By.xpath("//table[@id='customers']//tr["+r+"]//td[3]")).getText();
			System.out.println(name);
		}
	}
}
