package Day11MouseHoverAction;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHoverAction {
	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		
//		driver.get("https://www.amazon.in");
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_ev_ondblclick3");
		driver.manage().window().maximize();
		
		WebElement mxPlayer = driver.findElement(By.xpath("//*[@id='nav-xshop']/ul/li[2]/div/a"));
		WebElement Sell = driver.findElement(By.xpath("//*[@id='nav-xshop']/ul/li[3]/div/a"));
		
		Actions act = new Actions(driver);
		
//		Mouse hover
//		act.moveToElement(mxPlayer).moveToElement(Sell)  .build().perform();
		
//		Right click action
//		act.contextClick(mxPlayer).perform();
		
//		double click
		WebElement box1 = driver.findElement(By.xpath("//input[@id='field1']"));
		WebElement box2 = driver.findElement(By.xpath("//input[@id='field1']"));
		WebElement button = driver.findElement(By.xpath(" //button[contains(text(), 'Copy Text')]"));
		
		box1.clear();
		box1.sendKeys("WELCOME");
		
//		Double click action on the button
		act.doubleClick(button).perform();
		
	}
}
