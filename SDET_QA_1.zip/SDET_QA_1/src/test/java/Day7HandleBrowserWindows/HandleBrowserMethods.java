package Day7HandleBrowserWindows;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleBrowserMethods {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.amazon.in");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("xpath")).click();
		
		Set<String> windowIds = driver.getWindowHandles();
		
//		Approach1
		List<String> windowList = new ArrayList(windowIds);
		
		String parentId = windowList.get(0);
		String childId = windowList.get(1);
		
//		switch to child window
		driver.switchTo().window(childId);
		System.out.println(driver.getTitle());
		
//		swicth to parent window
		driver.switchTo().window(parentId);
		System.out.println(driver.getTitle());
		
//		Approach2
		
		for (String winId:windowIds) {
			String title = driver.switchTo().window(winId).getTitle();
			if (title.equals("requiresString")) {
				System.out.println(driver.getCurrentUrl());
			} else {
				System.out.println(driver.getCurrentUrl());
			}
		}
		
//		to delete particular windowId
		
		for (String winId:windowIds) {
			String title = driver.switchTo().window(winId).getTitle();
			if (title.equals("requiresString")) {
				driver.close();
			}
		}
		
		
	}
}
