package Day8HandleCheckBoxes;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandleCheckBoxes {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		WebDriverWait myWait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.manage().window().maximize();
		
//		1) Specific checkbox
		driver.findElement(By.xpath("")).click();
		
//		2) Select all the checkboxes
		List<WebElement> checkboxes = driver.findElements(By.xpath(""));
//		for (int i = 0; i <checkboxes.size(); i++) {
//			checkboxes.get(i).click();
//		}
//		
//		for (WebElement checkbox: checkboxes) {
//			checkbox.click();
//		}
//		
		
//		select first 3 and last 3 checkboxes
		
//		5) Unselect checkboxes if they are selected
		for (int i = 0; i < 3; i++) {
			checkboxes.get(i).isSelected();
		}
		
		Thread.sleep(5000);
		
		for (int i = 0; i < checkboxes.size(); i++) {
			if (checkboxes.get(i).isSelected()) {
				checkboxes.get(i).click();
			}
		}
		
		Alert myAlert = driver.switchTo().alert();
		System.out.println(myAlert.getText());
		myAlert.accept();
		
//		2) Confirmation Alert - OK & Cancel
		driver.findElement(By.xpath("")).click();
		driver.switchTo().alert().accept();  // close alert using ok button
		driver.switchTo().alert().dismiss(); // close alert using cancel button
		
//		3) Prompt alert - Input box
		driver.findElement(By.xpath("")).click();
		Thread.sleep(5000);
		
		Alert myAlert1 = driver.switchTo().alert();
		myAlert1.sendKeys("Welome");
		myAlert1.accept();
		
		Alert myAlertWait = myWait.until(ExpectedConditions.alertIsPresent());
		System.out.println(myAlertWait.getText());
		myAlertWait.accept();
	}
}
