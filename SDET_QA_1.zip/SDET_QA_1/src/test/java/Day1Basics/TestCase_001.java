package Day1Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.edge.EdgeDriver;
/* 
 * Test Case
 * ------
 * 1) Launch Browser (chrome)
 * 2) Open URL 
 * 3) Validate title should be "Your store"
 * 4) close Browser
 * */

public class TestCase_001 {
	public static void main(String[] args) {
		
		//1 Launch browser (chrome)
//		WebDriver driver = new ChromeDriver();
		WebDriver driver = new EdgeDriver();
		//2) Open url
		driver.get("https://www.amazon.com/");
		
		//3) Validate title should be "Your Store"
		String actTitle = driver.getTitle();
		
		if (actTitle.equals("Your Store")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("Test Failed");
		}
		
		//4) close the browser
//		driver.close();
		driver.quit();
	}
}
