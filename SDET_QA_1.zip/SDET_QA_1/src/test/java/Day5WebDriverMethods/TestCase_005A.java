package Day5WebDriverMethods;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.edge.EdgeDriver;

public class TestCase_005A {
	public static void main(String[] args) {
		WebDriver driver = new EdgeDriver();
		
		driver.get("https://www.amazon.in");
		driver.manage().window().maximize();
		
		System.out.println(driver.getTitle());
		
		System.out.println(driver.getCurrentUrl());
		
//		System.out.println(driver.getPageSource());
		
		driver.findElement(By.xpath("//*[@id=\"nav-link-accountList-nav-line-1\"]")).click();
		Set<String> windowId = driver.getWindowHandles();
		System.out.println(windowId);
	}
}
