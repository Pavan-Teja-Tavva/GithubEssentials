package Day5WebDriverMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.edge.EdgeDriver;

public class TestCase_005B {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.nopcommerce.com/register");
		driver.manage().window().maximize();
		
		WebElement logo = driver.findElement(By.xpath("//img[@alt='nopCommerce demo store']"));
		System.out.println(logo.isDisplayed());
		
//		boolean status = driver.findElement(By.xpath("//input[@data-val-required='First name is required.']")).isEnabled();
//		System.out.println(status);
//		
//		System.out.println("Before selection...");
//		WebElement male_stat = driver.findElement(By.xpath("//input[@id='gender-male']"));
//		WebElement female_stat = driver.findElement(By.xpath("//input[@id='gender-female']"));
//		System.out.println(male_stat.isSelected());
//		System.out.println(female_stat.isSelected());
//		
//		System.out.println("After selection...");
//		male_stat.click();
//		System.out.println(male_stat.isSelected());
//		System.out.println(female_stat.isSelected());
		
		driver.quit();

	}
}
