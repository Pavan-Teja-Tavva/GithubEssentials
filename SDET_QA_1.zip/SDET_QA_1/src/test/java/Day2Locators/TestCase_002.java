package Day2Locators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;

public class TestCase_002 {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.amazon.com");
		driver.manage().window().maximize();
		
//		name
//		driver.findElement(By.name("field-keywords")).sendKeys("Mac");
		
//		id
//		boolean logoStatus = driver.findElement(By.id("nav-logo")).isDisplayed();
//		System.out.println(logoStatus);
		
//		className
		List<WebElement> list = driver.findElements(By.className("nav-ul"));
		
		Thread.sleep(3000);
		
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getText());
//			System.out.println(list.size());
		}
		
//		System.out.println(list.size());
		
		// tagName
		List<WebElement> links = driver.findElements(By.tagName("a"));
		System.out.println(links.size());
		
		List<WebElement> images = driver.findElements(By.tagName("img"));
		System.out.println(images.size()); 
		
	}
}
