package com.scripts.tests;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import Junit4_Mthods_lib.UnitTestMethods;
import junit.framework.Assert;

public class RunMyScript {
	UnitTestMethods unitTest = new UnitTestMethods();
	
	@Test
	public void test_calculator() {
//		int expsum = 30;
//		fail("Not yet implemented");
		int sumact = unitTest.Calculate_Sum(10, 20);
		int sumexp = 30;
		assertEquals(sumact, sumexp);
		 
	}
	
	@Test
	public void test_Basesal() {
		double expBsal = 24500.00;
		double actBsal = unitTest.BaseSal(30000.00);
//		Assert.
		Assert.assertEquals("Both salarie must be same", expBsal, actBsal);
	}
	
	@Test
	public void test_Concat()
	{
		String expString = "HelloWorld";
		String actString = unitTest.PerformConcatination("Hello", "World");
		Assert.assertEquals("Strings must be same", expString, actString);
	}
	
	@Test
	public void test_Array() {
		int[] expArr = {1,2,3};
		int[] actArr = unitTest.MyArrayValues();
		assertArrayEquals(expArr, actArr);
	}
	
	@Test
	public void test_List() {
		List<Integer> expList = Arrays.asList(10,20,30,40);
		List<Integer> actList = unitTest.TestList();
		assertEquals("values must be same", expList, actList);
	}
}
