package Junit4_Mthods_lib;

import java.util.Arrays;
import java.util.List;

public class UnitTestMethods {
	
//	 int
	public int Calculate_Sum(int x, int y) {
		int sum = x+y;
		return sum;
	}
	
//	double
	public double BaseSal(double gross) {
		double base1 = gross - 5500.00;
		return base1;
	}
	
	public String PerformConcatination(String s1, String s2) {
		String s3 = s1.concat(s2);
		return s3;
	}
	
	public int[] MyArrayValues() {
		int arr[] = {1,2,3};
		return arr;
	}
	
	public List<Integer> TestList() {
		List<Integer> list1 = Arrays.asList(10,20,30,40);
		return list1;
	}
}
