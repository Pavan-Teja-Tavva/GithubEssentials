package D_ConfirmationPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import C_AppointmentPage.AppointmentPage;

public class ConfirmationPage extends AppointmentPage {
	public void confirmation(WebDriver driver) {
		
		WebElement confirm = driver.findElement(By.xpath("//*[@id='summary']/div/div/div[1]/h2"));
		String Confirm = confirm.getText();
		System.out.println(Confirm.equals("Appointment Confirmation"));
		
		System.out.println("Finally appointment has been booked sir!!");
	}
}
