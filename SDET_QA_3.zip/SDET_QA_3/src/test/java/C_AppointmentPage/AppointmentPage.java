package C_AppointmentPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import B_LoginPage.LoginPage;

public class AppointmentPage extends LoginPage{
	public void appointmentPage(WebDriver driver) {
		
		
		WebElement text1 = driver.findElement(By.xpath("//*[@id='appointment']/div/div/div/h2"));
		String word1 = text1.getText();
		System.out.println(word1.equals("Make Appointment"));
		 
		WebElement sel = driver.findElement(By.xpath("//*[@id='combo_facility']"));
		Select select = new Select(sel);
		select.selectByVisibleText("Seoul CURA Healthcare Center");
		
		WebElement check = driver.findElement(By.xpath("//*[@id='appointment']/div/div/form/div[2]/div/label"));
		check.click();
		
		WebElement radio = driver.findElement(By.xpath("//*[@id='radio_program_medicare']"));
		radio.click();
		
		WebElement Cal = driver.findElement(By.xpath("//input[@id='txt_visit_date']"));
		Cal.sendKeys("30/04/2025");
		
		WebElement comment = driver.findElement(By.xpath("//textarea[@id='txt_comment']"));
		comment.sendKeys("Select the required options");
		
		WebElement book = driver.findElement(By.xpath("//button[@id='btn-book-appointment']"));
		book.click();
	}
}
