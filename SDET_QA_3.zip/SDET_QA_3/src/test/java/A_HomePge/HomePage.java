package A_HomePge;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class HomePage {
	
	
	public WebDriver driver;

	public void init_webdriver(WebDriver driver) {
		this.driver = driver;
	}
	
	public void launch(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://katalon-demo-cura.herokuapp.com");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"top\"]/div/h1"));
		String word = text.getText();
		System.out.println(word.equals("CURA Healthcare Service"));
		
	}
	
	public void click_appointment(WebDriver driver) {
		WebElement appointment = driver.findElement(By.xpath("//*[@id='btn-make-appointment']"));
		appointment.click();
	}
}
