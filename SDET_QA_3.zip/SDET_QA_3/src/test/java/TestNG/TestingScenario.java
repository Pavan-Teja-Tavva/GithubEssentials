package TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import A_HomePge.HomePage;
import D_ConfirmationPage.ConfirmationPage;

public class TestingScenario {
	WebDriver driver = new EdgeDriver();
	ConfirmationPage con = new ConfirmationPage();
  @Test
  public void method1() {
	  con.init_webdriver(driver);
	  con.launch(driver);
	  con.click_appointment(driver);
  }
  
  @Test
  public void method2() {
	  con.login(driver);
  }
  
  @Test
  public void method3() {
	  con.appointmentPage(driver);
  }
  
  @Test
  public void method4() {
	  con.confirmation(driver);
  }
  
  
}
