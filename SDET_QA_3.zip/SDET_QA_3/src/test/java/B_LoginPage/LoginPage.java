package B_LoginPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import A_HomePge.HomePage;

public class LoginPage extends HomePage {
	public void login(WebDriver driver) {
		driver.findElement(By.xpath("//*[@id='txt-username']")).sendKeys("John Doe");
		driver.findElement(By.xpath("//*[@id='txt-password']")).sendKeys("ThisIsNotAPassword");
		
		driver.findElement(By.xpath("//*[@id='btn-login']")).click();
	}
}
